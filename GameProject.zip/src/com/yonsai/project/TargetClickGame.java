package com.yonsai.project;

import com.yonsai.project.domain.GameData;
import com.yonsai.project.service.GameService;
import com.yonsai.project.view.GameUI;
import javax.swing.SwingUtilities;

/**
 * [Main Entry Point]
 * 프로그램의 시작점이며, 각 패키지의 클래스들을 인스턴스화하고 조립하여 게임을 구동시킵니다.
 */
public class TargetClickGame {
    public static void main(String[] args) {
        // Swing GUI를 안전하게 실행하기 위한 스레드 처리
        SwingUtilities.invokeLater(() -> {
            // 1. 데이터 저장 공간 생성 (Domain) - 제한시간 20초 설정
            GameData data = new GameData(20);

            // 2. 화면 디자인 생성 (View)
            GameUI ui = new GameUI();

            // 3. 로직 처리 해결사 생성 및 조립 (Service)
            GameService service = new GameService(data, ui);

            // 4. 이벤트 연결 및 작동 시작!
            ui.initEvents(service);
            ui.setVisible(true);
            ui.startTimers();
        });
    }
}