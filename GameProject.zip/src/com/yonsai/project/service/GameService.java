package com.yonsai.project.service;

import com.yonsai.project.domain.GameData;
import com.yonsai.project.view.GameUI;
import java.util.Random;

/**
 * [Service Layer]
 * 게임의 비즈니스 로직(연산, 규칙 검사 등)을 처리하는 핵심 클래스입니다.
 */
public class GameService {
    private final GameData data;  // 데이터 저장소 참조 (Domain)
    private final GameUI ui;      // 화면 UI 참조 (View)
    private final Random random = new Random();

    public GameService(GameData data, GameUI ui) {
        this.data = data;
        this.ui = ui;
    }

    // [규칙 1] 타겟 클릭 성공 시 점수 상승 및 이동
    public void processTargetClick() {
        if (!data.isGameRunning()) return;

        // 점수 10점 누적
        data.setScore(data.getScore() + 10);
        
        // UI 반영 지시
        ui.updateScoreLabel(data.getScore());
        
        // 타겟 무작위 이동 처리 및 자동이동 타이머 리셋
        relocateTarget();
        ui.restartMoveTimer();
    }

    // [규칙 2] 1초마다 남은 시간 차감 및 시간 초과 판단
    public void processTimeTick() {
        if (!data.isGameRunning()) return;

        int updatedTime = data.getTimeLeft() - 1;
        data.setTimeLeft(updatedTime);
        
        // 시간 텍스트 최신화 지시
        ui.updateTimerLabel(updatedTime);

        // 시간 초과 시 게임 종료
        if (updatedTime <= 0) {
            processGameOver();
        }
    }

    // [규칙 3] 타겟을 무작위 좌표로 이동시키는 연산
    public void relocateTarget() {
        int panelW = ui.getPanelWidth();
        int panelH = ui.getPanelHeight();
        int targetW = ui.getTargetWidth();
        int targetH = ui.getTargetHeight();

        // 타겟이 경계 밖으로 벗어나지 않도록 범위 제약 계산
        int maxX = panelW - targetW;
        int maxY = panelH - targetH - 50; // 상단 정보 영역 침범 방지

        if (maxX > 0 && maxY > 0) {
            int randomX = random.nextInt(maxX);
            int randomY = random.nextInt(maxY) + 50; // Y좌표는 상단 라벨 영역 회피를 위해 최소 50
            ui.setTargetPosition(randomX, randomY);
        }
    }

    // [규칙 4] 게임 종료 시 프로세스 실행
    private void processGameOver() {
        data.setGameRunning(false);
        ui.stopAllTimers();
        ui.disableTargetButton();
        ui.showResultPopup(data.getScore());
        System.exit(0); // 프로그램 즉시 종료
    }
}