package com.yonsai.project.domain;

/**
 * [Domain Layer]
 * 게임의 순수한 데이터(상태 값)만 보관하는 클래스입니다.
 * 다른 패키지에서 접근할 수 있도록 public 클래스로 선언합니다.
 */
public class GameData {
    private int score;          // 현재 획득 점수
    private int timeLeft;       // 남은 제한 시간
    private boolean gameRunning; // 게임이 진행 중인지 여부

    public GameData(int initialTime) {
        this.score = 0;
        this.timeLeft = initialTime;
        this.gameRunning = true;
    }

    // 외부 패키지(Service)에서 데이터를 읽고 수정할 수 있도록 public getter/setter 제공
    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getTimeLeft() {
        return timeLeft;
    }

    public void setTimeLeft(int timeLeft) {
        this.timeLeft = timeLeft;
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public void setGameRunning(boolean gameRunning) {
        this.gameRunning = gameRunning;
    }
}