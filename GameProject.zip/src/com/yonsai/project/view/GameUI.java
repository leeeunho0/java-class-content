package com.yonsai.project.view;

import com.yonsai.project.service.GameService;
import javax.swing.*;
import java.awt.*;
import java.net.URL; // 인터넷 URL 주소를 처리하기 위해 추가

/**
 * [View Layer]
 * 사용자 화면을 그리고 마우스/타이머 이벤트를 수신하여 서비스에 전달하는 클래스입니다.
 */
public class GameUI extends JFrame {
    private JPanel mainPanel;       // 도화지 패널
    private JButton targetButton;   // 클릭할 🎯 버튼
    private JLabel scoreLabel;      // 점수판 라벨
    private JLabel timerLabel;      // 타이머 라벨
    private Timer gameTimer;        // 1초 감소용 실시간 타이머
    private Timer moveTimer;        // 1.2초 자동도망용 타이머

    public GameUI() {
        setupWindow();
        createComponents();
    }

    private void setupWindow() {
        setTitle("🎯 초고속 타겟 클릭 게임! (패키지 분리 완료)");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void createComponents() {
        mainPanel = new JPanel();
        mainPanel.setLayout(null); // 좌표 기반 절대 배치
        mainPanel.setBackground(new Color(240, 248, 255));

        scoreLabel = new JLabel("Score: 0", SwingConstants.CENTER);
        scoreLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        scoreLabel.setBounds(20, 10, 150, 30);
        mainPanel.add(scoreLabel);

        timerLabel = new JLabel("Time: 20s", SwingConstants.CENTER);
        timerLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        timerLabel.setForeground(Color.RED);
        timerLabel.setBounds(410, 10, 150, 30);
        mainPanel.add(timerLabel);

        // [변경 부분] 🎯 이모지 대신 인터넷 URL 이미지를 로드하여 버튼에 적용합니다.
        try {
            // 라인 스티커 이미지 URL 주소 설정
            URL imageUrl = new URL("https://stickershop.line-scdn.net/stickershop/v1/product/6225285/LINEStorePC/main.png?v=1");
            ImageIcon originalIcon = new ImageIcon(imageUrl);
            
            // 이미지 크기를 버튼 크기(70x70)에 맞게 고품질 스케일링 처리
            Image scaledImage = originalIcon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
            ImageIcon scaledIcon = new ImageIcon(scaledImage);
            
            targetButton = new JButton(scaledIcon);
            
            // 투명 PNG 스티커 이미지를 완벽하게 살리기 위해 버튼의 회색 외곽선과 투박한 배경색을 제거
            targetButton.setBorderPainted(false);      // 외곽선 없애기
            targetButton.setContentAreaFilled(false);  // 배경 채우기 해제 (투명화)
            targetButton.setFocusPainted(false);       // 클릭 시 포커스 테두리 제거
            
        } catch (Exception e) {
            // 인터넷 미연결 또는 예외 발생 시 게임 플레이를 보장하기 위해 🎯 기본 이모지 버튼으로 백업 작동
            targetButton = new JButton("🎯");
            targetButton.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
            targetButton.setBackground(Color.YELLOW);
        }
        
        targetButton.setBounds(250, 200, 70, 70);
        mainPanel.add(targetButton);

        add(mainPanel);
    }

    // 중요 이벤트를 Service와 연결해주는 중개 메서드
    public void initEvents(GameService service) {
        // [이벤트 1] 타겟 클릭 시 서비스의 로직 작동
        targetButton.addActionListener(e -> service.processTargetClick());

        // [이벤트 2] 1초마다 서비스의 시간차감 작동
        gameTimer = new Timer(1000, e -> service.processTimeTick());

        // [이벤트 3] 1.2초마다 타겟 자동 이동 작동
        moveTimer = new Timer(1200, e -> service.relocateTarget());
    }

    // 타이머 및 화면 최신화 제어 유틸리티 메서드들 (외부에서 호출할 수 있게 public 설정)
    public void startTimers() {
        gameTimer.start();
        moveTimer.start();
    }

    public void stopAllTimers() {
        if (gameTimer != null) gameTimer.stop();
        if (moveTimer != null) moveTimer.stop();
    }

    public void restartMoveTimer() {
        if (moveTimer != null) moveTimer.restart();
    }

    public void updateScoreLabel(int score) {
        scoreLabel.setText("Score: " + score);
    }

    public void updateTimerLabel(int timeLeft) {
        timerLabel.setText("Time: " + timeLeft + "s");
    }

    public void setTargetPosition(int x, int y) {
        targetButton.setLocation(x, y);
    }

    public void disableTargetButton() {
        targetButton.setEnabled(false);
    }

    public void showResultPopup(int score) {
        JOptionPane.showMessageDialog(this,
                "⏰ Game Over! ⏰\n최종 점수: " + score + "점",
                "게임 결과",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // 크기 연산을 위해 Service에 수치를 넘겨주는 Getter 메서드들
    public int getPanelWidth() { return mainPanel.getWidth(); }
    public int getPanelHeight() { return mainPanel.getHeight(); }
    public int getTargetWidth() { return targetButton.getWidth(); }
    public int getTargetHeight() { return targetButton.getHeight(); }
}